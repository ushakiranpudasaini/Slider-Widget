<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * grid Elementor Card Widget.
 *
 * Elementor widget that inserts card with title and description.
 *
 * @since 1.0.0
 */
class monalslider_Elementor_Card_Widget extends \Elementor\Widget_Base {
//Our widget code goes here

/**
	 * Get widget name.
	 *
	 * Retrieve Card widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
public function get_name() {
    return 'card';
}

/**
	 * Get widget title.
	 *
	 * Retrieve Card  widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Monal Slider ', 'monalslider-elementor-widget' );
	}

    /**
	 * Get widget icon.
	 *
	 * Retrieve Card widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-header';
	}

    /**
	 * Get custom help URL.
	 *
	 * Retrieve a URL where the user can get more information about the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget help URL.
	 */
	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

    /**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the card widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'layout' ];
	}

    /**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the card widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'card', 'service', 'highlight', 'grid'];
	}

    	/**
	 * Register Card widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'monalslider-elementor-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		// $this->add_control(
		// 	'query',
		// 	[
		// 		'label' => __('Query', 'your-text-domain'),
		// 		'type' => \Elementor\Controls_Manager::TEXT, // Adjust the control type as needed
		// 		'default' => '', // Set a default query value
		// 	]
		// );
		$this->add_control(
			'content_source',
			[
				'label' => __('Content Source', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'posts', // Set your default content source
				'options' => [
					'posts' => __('Posts', 'your-text-domain'),
					'custom_post_type' => __('Custom Post Type', 'your-text-domain'),
					// Add more options for different content sources
				],
			]
		);
		$this->add_control(
			'slider_speed',
			[
				'label' => __('Slider Speed (ms)', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 3000, // Set your default slider speed
			]
		);
		$this->add_control(
			'number_of_posts',
			[
				'label' => __('Number of Posts', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5, // Set your default number of posts
			]
		);
		$this->add_control(
			'selected_category',
			[
				'label' => __('Select Category', 'your-text-domain'),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '0', // Default to show all categories
				'options' => $this->get_post_categories(),
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( ' Style', 'monalslider-elementor-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_options',
			[
				'label' => esc_html__( ' Title Options', 'monalslider-elementor-widget' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'monalslider-elementor-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' =>'#f00',
				'selectors' => [
					'{{WRAPPER}} h3' => 'color: {{VALUE}};',				
				],
			]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} h3', 
				]
			);
//Description
			$this->add_control(
				'description_options',
				[
					'label' => esc_html__( ' Description Options', 'monalslider-elementor-widget' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
	
			$this->add_control(
				'description_color',
				[
					'label' => esc_html__( 'Color', 'monalslider-elementor-widget' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' =>'#f00',
					'selectors' => [
						'{{WRAPPER}} .card_description' => 'color: {{VALUE}};',				
					],
				]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'description_typography',
						'selector' => '{{WRAPPER}} .card_description', 
					]
				);
		$this->end_controls_section();

    }

	/**
	 * Render card widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */


	 private function get_post_categories() {
		$categories = get_terms([
			'taxonomy' => 'category', // Change to your custom taxonomy if needed
			'hide_empty' => false, // Set to true to hide empty categories
		]);
	
		$category_options = ['0' => 'All Categories']; // Default option to show all categories
	
		foreach ($categories as $category) {
			$category_options[$category->term_id] = $category->name;
		}
	
		return $category_options;
	}
		


protected function render() {
    $settings = $this->get_settings_for_display();
    // $slider_query = new WP_Query($settings['query']); // Assuming you have a query for posts
	$selected_category = $settings['selected_category'];

	// Set your query args
	$query_args = [
		'post_type' => 'post', // Use your post type if different
		'posts_per_page' => $settings['number_of_posts'],
	];
	
	if ($selected_category !== '0') {
		$query_args['cat'] = $selected_category;
	}
	
	$slider_query = new WP_Query($query_args);
	


    if ($slider_query->have_posts()) {
        echo '<div class="slider-container">'; // Create a container for the slider
        echo '<div class="slick-slider">'; // Create a container for the Slick Slider

        while ($slider_query->have_posts()) {
            $slider_query->the_post();

            // Get post details
            $post_title = get_the_title();
            $post_content = get_the_content();

            // Get image URL and dimensions
            $featured_image_id = get_post_thumbnail_id();
            $featured_image = wp_get_attachment_image_src($featured_image_id, 'large');
            $image_url = $featured_image[0];
            $image_width = $featured_image[1];
            $image_height = $featured_image[2];

            echo '<div class="slider-item">';
            echo '<div class="post-details ">'; // Create a container for post title and description

            echo '<h2 class="text-xl md:text-3xl text-gray-50 mb-6">' . esc_html($post_title) . '</h2>'; // Display post title
            echo '<p class="text-gray-400">' . esc_html($post_content) . '</p>'; // Display post description

            echo '</div>'; // Close the container for post title and description

            echo '<div class="image-container">'; // Create a container for the image
			echo '<div class="image-overlay"></div>';
			echo '<img src="' . esc_url($image_url) . '" alt="' . esc_attr(get_the_title()) . '" width="' . esc_attr($image_width) . '" height="' . esc_attr($image_height) . '" class="w-full">';
            echo '</div>'; // Close the container for the image

            echo '</div>';
        }

        echo '</div>';
        echo '</div>';
        echo '<div class="slider-dots"></div>';
        echo '<div class="slider-arrows">
        <button class="slick-prev">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
            <path d="M15.41 16.58L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41" fill="#ffffff"/>
        </svg>
        </button>
        <button class="slick-next">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
            <path d="M10.59 8.59L15.17 13l-4.58 4.59L12 18l6-6-6-6-1.41 1.41" fill="#ffffff"/>
        </svg>
        </button>
        </div>';

        echo '<script>
            jQuery(document).ready(function($) {
                $(".slick-slider").slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: true,
                    autoplaySpeed: ' . intval($settings['slider_speed']) . ',
                    infinite: true,
                    dots: true,
                    prevArrow: $(".slick-prev"),
                    nextArrow: $(".slick-next"),
                });
            });
        </script>';

        echo '<style>
	
		@media only screen 
and (min-width : 321px)
and (max-width : 767px)
{
			/* Mobile styles here */
			.slider-container {
				max-height: 800px!important;
			}
			.slick-dots {
				display: none!important;
			}
			.post-details {
				top: 50%!important;
				left: 50%;
				transform: translate(-50%, -50%);
				width:100%;
				padding:2px;
			}
			.image-overlay {
				background-color: rgba(0, 0, 0, 0.7); /* Adjust the overlay opacity for mobile */
			}
		}
		
            .slider-container {
                position: relative;
                width: 100%;
                max-height: 700px;
                overflow: hidden;
                text-align: center;
            }
            .slider-item {
                width: 100%;
                height: 100%;
                text-align: center;
                position: relative;
            }
            .post-details {
               
                color: #fff;
                padding: 20px;
                position: absolute;
                top: 30%;
                left: 50%;				
                transform: translate(-50%, -50%);
				z-index:100;
				display: flex; /* Use flexbox to center content */
				flex-direction: column;
				justify-content: center; /* Vertically center the content */
				align-items: center; 
            }
            .image-container {
                width: 100%;
                height: 100%;
            }
            .image-container img {
                width: 100%;
                height: 100%;
            }
            .slick-prev,
            .slick-next {
                color: #fff;
                background-color: #333;
                font-size: 18px;
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
            }
            .slick-prev {
                left: 10px;
            }
            .slick-next {
                right: 10px;
            }
			.image-overlay {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5); /* You can change the color and opacity here */
            }
        </style>';
    }

    wp_reset_postdata();
}


// ...

	
	
	
}